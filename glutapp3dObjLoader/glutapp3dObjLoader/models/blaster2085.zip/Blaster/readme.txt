Blasterer (aka Blaster: 2085)
~~~~~~~~~

A remake of Williams' "Blaster" by Jum.


"The year is 2085 and the Robotrons have destroyed the human race."

Rumour has it that the few remaining survivors have fled to an uncharted planet called "Paradise". Can you make it through 20 zones of heavily-guarded Robotron space to get to "Paradise"?

I think not. But it's worth a try, right?

You will be rewarded for picking up any straggling survivors along the way.


How to Play:

Run "Blaster.exe"


Controls:

Use the arrow keys or the joystick to steer your space fighter. Press "Space" or the 1st joystick button to fire your plasma cannon.

Note that this game plays much better with a joystick, and that the joystick needs to be configured properly in Windows Control Panel.


Your Shield:

You start with three lives, and you are awarded an extra life every 100,000 points. You lose a life if you are hit by enemy fire or crash into anything without having any remaining energy shield. Your shield indicator at the top of the screen lets you know how many shield energy you have left.


The Enemies:

We know little about the Robotrons, but we do know that you will encounter:

	Robotron "Grunts" - scour the surface of planets for human survivors to "reprogram"
	Robotron "Flyers" - planetside scout planes
	Robotron "Saucers" - space vehicles

... plus probably many more hostile Robotron craft which are programmed to destroy any human intruders.

Remember, Robotrons aren't programmed to negotiate.

	 


Known Issues:
1. You'll never get to Paradise...
2. It looks and runs crap on an Intel "Extreme" 82865G gfx card (but it was developed using and runs great on an nVidia TNT2).


So have fun with this "Blaster from the past" (har har).

- Jum (aka James Higgs)
29/9/2004







